DarkChat (C) 1997 by Sierra Kempster.  All rights reserved.
This script is freeware, but please do not distribute without this notice,
and email darkmoon@calweb.com to let me know it's being used.  I won't butt
in, but I like to know when my work is appreciated! :)
Inspired by Mike Wheeler's ChatPro.
For more information, email: darkmoon@lunamorena.net or visit the scripts
page at http://www.lunamorena.net/perl/
About: 
    DarkChat is a CGI script written in perl for use on my own web site.  I
    was using Mike Wheeler's ChatPro (http://www.freescripts.com/) but
    didn't care for some of the interface, so I wrote my own.  It doesn't
    have the multi-room capabilities of Mike's script (yet!), but for my
    personal site, it doesn't really need it.  It can still do private
    messages, and I think that's a private as somthing like this needs to
    get, at least for now.
Installation:
    The first thing to need to do for this script is the installation.  When
    you un-TAR the file, it should put everything where it needs to be, but
    you will still need to set the permissions as shown below:
    
    drwxr-xr-x ./
    -rw-r--r-- ./background.gif
    -rw-r--r-- ./chat.gif
    -rw-r--r-- ./chatblt.gif
    -rwxr-xr-x ./darkchat.pl
    -rw-rw-r-- ./help.html
    -rw------- ./README.txt
    drwxr-xr-x ./users/
    In other words, the darkchat.pl script, the users/ directory, and the
    directory containing them need to be chmod 755 and everything else needs
    to be chmod 644.  The README.txt file can be anything (is shown chmod
    600) since no one besides you needs to read it.
    
    Some servers do not work with this configuration, normally marked by an
    inability to read anything that's posted.  If this is the case, change
    the root and users/ directories to chmod 777.  This is less secure but
    more likely to work.
    
    Next you need to open up the darkchat.pl file in your favorite text
    editor and configure the options as follows:
    
    $title
    This should be the title you want to have for your chat program.
    
    $title_graphic
    This is the graphic used for your chat's title.  One is included with
    this archive (chat.gif), but it is for my own chat program.  You're
    welcome to use it if you like, but I'd rather you didn't.  You should
    really try to be original. :)  If you don't have one, that's okay too.
    
    $background
    The background image for your chat.  Included is background.gif, which
    is a very dark grey with a light texture.  Again, it was designed for my
    own page, but is less page-specific than my title graphic.  Use it, or
    don't.
    
    $bgcolor
    The bacground color (bgcolor of the body tag) for your chat, in #RRGGBB
    format.
    
    $text
    Text color for your chat, in #RRGGBB
    
    $link
    Link color
    
    $vlink
    vlink color
    
    $alink
    alink color
    
    $oldcolor = "#7700FF";
    Color for old messages
    
    $actioncolor
    Color for actions
    
    $privcolor
    Color for private messages
    
    $keep
    Time (in seconds) to keep messages.
    
    $this_script
    URL for this script
    
    $data_path
    Path for data files
       Usually this will be the full path of the script.  The #1 reason I've
       found that people have had trouble with the script (after
       permissions) is this being set incorrectly.  This needs to be the
       directory CONTAINING the users/ directory, so by default this is the
       directory containing the script as well.  So, for example, if the
       path to the users directory is:
       /usr/home/username/public_html/cgi-bin/darkchat/users/
       then the $data_path needs to be set to:
       /usr/home/username/public_html/cgi-bin/darkchat
   
    $leave_url
    URL users go to when they hit the "Leave" button.

    $help_url
    URL for help file
    
    $chat_blt
    Image to indicate new message.  Included is chatblt.gif.  Use it or
    don't.
    
    Once that's done, you should be ready to go.

    
If you have any questions, you can email me at skempster@tech.jps.net and
I'll help you as best I can.  Be sure to give me the error message(s) you're
getting and the URL for the script, if possible.  Before emailing me, be
sure you have everything (especially the permissions) configured correctly.
README.txt revised Mon Apr  5 18:32:07 PDT 1999
