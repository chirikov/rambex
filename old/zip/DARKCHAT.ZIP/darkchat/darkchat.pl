#!/usr/local/bin/perl

# DarkChat (C) 1997 by Sierra Kempster.  All rights reserved.

# This script is freeware, but please do not distribute without this notice,
# and email darkmoon@lunamorena.net to let me know it's being used.  I won't
# butt in, but I like to know when my work is appreciated! :)
# Inspired by Mike Wheeler's ChatPro.

# For more information, email: darkmoon@lunamorena.net or visit Darkmoon's home
# page at http://www.lunamorena.net/

#################
# Configuration #
#################

$title = "Darkmoon's Web Chat";
$title_graphic = "/~darkmoon/cgi-bin/darkchat/chat.gif";

# BODY tag
$background = "/~darkmoon/cgi-bin/darkchat/background.gif";
$bgcolor = "#222222";
$text = "#FFFFAA";
$link = "#AAFFAA";
$vlink = "#AAAAFF";
$alink = "#AAFFAA";

# Color for old messages
$oldcolor = "#7700FF";
# Color for actions
$actioncolor = "#AAFFAA";
# Color for private messages
$privcolor = "#FFFFFF";
# Time (in seconds) to keep messages.
$keep = 1200;
# URL for this script - you won't have to change this on most servers.
$this_script = "darkchat.pl";
# Path for data files
$data_path = "/www/home/users/d/darkmoon/cgi-bin/darkchat";
# URL users go to when they hit the "Leave" button.
$leave_url = "http://www.lunamorena.net/";
# URL for help file
$help_url = "http://www.lunamorena.net/perl/darkchat/help.html";
# Image to indicate new message
$chat_blt = "/~darkmoon/cgi-bin/darkchat/chatblt.gif";

#####################
# End Configuration #
#####################
$ver = "1.1.1";
$salt = "chat";
@time = localtime(time);
foreach $time (@time) { $time = "0$time" if($time < 10); }
$nicetime = "$time[2]:$time[1]:$time[0]";
$time = time;
srand($$);

&parse_form;
if(($action =~ /[Pp]ost/) || ($action =~ /[Mm]ore/) || ($action =~ /[Cc]hat/))
{
  &begin;
  &check_user;
  &post if($action =~ /[Pp]ost/);
  undef $message if($action =~ /[Pp]ost/);
  &display;
  &end;
}
elsif($action =~ /[Pp]rivate/)
{
  &begin;
  &check_user;
  &private;
  &end;
}
elsif($to_name)
{
  &begin;
  &check_user;
  &send_private;
  &display;
  &end;
}
elsif($action =~ /[Ll]eave/)
{
  print"Location: $leave_url\n\n";
  $user = $username;
  &remove_user;
}
else
{
  &begin;
  if($title_graphic) { print"<center><img src=\"$title_graphic\" alt=\"$title\"></center><p>\n"; }
  else { print"<center><font size=7>$title</font></center><p>\n"; }
  &login;
  &end;
}

###############
# Subroutines #
###############

sub display
{
  &top;
  &reload;
  print"<center>\n";
  print"<table cellspacing=10>\n";
  print"<td width=20% valign=top>\n";
  &list_users;
  print"<p>\n";
  &show_private;
  print"</td>\n<td width=70% valign=top>\n";
  &show_messages;
  print"</td>\n";
  print"</table>\n</center>\n";
}

sub begin
{
  print"Content-type:text/html\n\n";
  print"<HTML>\n<HEAD>\n";
  print"<TITLE>$title</TITLE>\n";
  print"</HEAD>\n";
  print"<BODY";
  print" background=\"$background\"" if($background);
  print" bgcolor=\"$bgcolor\"" if($bgcolor);
  print" text=\"$text\"" if($text);
  print" link=\"$link\"" if($link);
  print" vlink=\"$vlink\"" if($vlink);
  print" alink=\"$alink\"" if($alink);
  if($action) { print" onLoad=\"document.input.message.focus()\""; }
  else { print" onLoad=\"document.input.username.focus()\""; }
  print">\n";
  print"<FORM name=input method=post action=\"$this_script\">\n";
  print"<input type=hidden name=\"oldtime\" value=\"$time\">\n";
}

sub parse_form
{
  read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
  @pairs = split(/&/, $buffer);
  foreach $pair (@pairs)
  {
    ($name, $value) = split(/=/, $pair);
    $value =~ tr/+/ /;
    $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
    $value =~ s/~!/ ~!/g;
    $value =~ s/\n//g;
    $FORM{$name} = $value;
  }
  $username = $FORM{username};
  $password = $FORM{password};
  $email = $FORM{email};
  $message = $FORM{message};
  $action = $FORM{action};
  $oldtime = $FORM{oldtime};
  $to_name = $FORM{to_name};
}

sub end
{
  print"</FORM><p>\n";
  print"DarkChat v$ver Copyright &copy; 1997 <a href=\"http://www.lunamorena.net/perl/darkchat.html\">Sierra Kempster</a>.  All rights reserved.\n";
  print"</BODY>\n</HTML>\n";
  exit;
}

sub login
{
  print"<center><table>\n";
  print"<td>Choose a Nickname:</td><td><input name=\"username\" size=30></td><tr>\n";
  print"<td>And a Password:</td><td><input type=password name=\"password\" size=30></td><tr>\n";
  print"<td>Your email or web address (optional):</td><td><input name=\"email\" size=30></td><tr>\n";
  print"<td align=center colspan=2><input type=submit name=\"action\" value=\"Chat\"> <input type=reset value=\"Clear\"></td>\n";
  print"</table></center>\n";
}

sub top
{
  print"<INPUT type=hidden name=\"username\" value=\"$username\">\n";
  print"<INPUT type=hidden name=\"password\" value=\"$password\">\n";
  print"<CENTER>\n";
  if($title_graphic) { print"<img src=\"$title_graphic\" alt=\"$title\"><p>\n"; }
  else { print"<h2>$title</h2><p>\n"; }
  print"<TEXTAREA name=\"message\" rows=5 cols=40 wrap=physical>$message</textarea><br>\n";
  print"<input type=submit name=\"action\" value=\"Post\">\n";
  print"<input type=submit name=\"action\" value=\"More\">\n";
  print"<input type=submit name=\"action\" value=\"Private\">\n";
  print"<input type=reset value=\"Clear\">\n";
  print"<input type=submit name=\"action\" value=\"Leave\">\n";
  print"</center>\n";
}

sub post
{
  $temp = (rand 10);
  system"cp $data_path/messages $data_path/$temp" if(-f "$data_path/messages");
  open(OLD, "$data_path/$temp") if(-f "$data_path/$temp");
  open(NEW, ">$data_path/messages");
  print(NEW "$username|$nicetime|$time|$message\n") if($message);
  if(-f "$data_path/$temp")
  {
    while(<OLD>) 
    {
      chomp;
      ($nick,$msgtime,$realtime,$post) = split(/\|/,$_,4);
      print(NEW "$_\n") if($realtime > $time-$keep);
    }
    close(OLD);
  }
  close(NEW);
  unlink"$data_path/$temp";
}

sub show_messages
{
  open(MESSAGES, "$data_path/messages");
  while(<MESSAGES>)
  {
    chomp;
    ($nick,$msgtime,$realtime,$post) = split(/\|/,$_,4);
    if($nick)
    {
      if($oldtime < $realtime)
      {
        if($chat_blt) { print"<img src=\"$chat_blt\">"; }
        else { print"*NEW*"; }
      }
      else { print"<font color=\"$oldcolor\">\n"; }
      if($nick =~ /^Join:/) 
      {
        ($type,$nickname) = split(/:/,$nick,2);
        print"$nickname has joined at $msgtime.\n"; 
      }
      elsif($nick =~ /^Leave:/)
      {
        ($type,$nickname) = split(/:/,$nick,2);
        print"$nickname has left at $msgtime.\n";
      }
      else
      {
        print"$nick said at $msgtime:<br>\n";
        $post =~ s/\r/<br>/g;
        $post =~ s/action\{(.*)\}/\<font color=$actioncolor\>$nick\ $1<\/font>/g;
        print"$post\n";
      }
      print"</font>\n<hr>\n";
    }
  }
  close(MESSAGES);
}

sub check_user
{
  $pass = crypt $password, $salt;
  if($username !~ /^\w+$/)
  {
    print"Usernames must be alphanumeric, with no spaces.<p>\n";
    &login;
    &end;
  }
  elsif($password !~ /^\w{3,}$/)
  {
    print"Passwords must be alphanumeric, at least 3 characters long, with no spaces.<p>\n";
    &login;
    &end;
  }
  elsif(-f "$data_path/users/$username")
  {
    open(PASSWORD, "$data_path/users/$username");
    while(<PASSWORD>)
    {
      if($_ =~ /^Pass:/)
      {
        chomp;
	($text,$passwd) = split(/:/,$_,2);
	if($pass ne $passwd)
	{
	  print"The username you have chosen has been taken by someone else, or you have entered the wrong username.<p>\n";
	  &login;
	  &end;
	}
	last;
      }
    }
  }
  else
  {
    open(PASSWORD, ">$data_path/users/$username");
    print(PASSWORD "Pass:$pass\n");
    print(PASSWORD "Email:$email\n") if($email);
    print(PASSWORD "Reload:$nicetime\n");
    print(PASSWORD "Time:$time\n");
    print(PASSWORD "IP:$ENV{REMOTE_ADDR}\n");
    print(PASSWORD "--NEW--\n");
    print(PASSWORD "From DarkChat:Click <a target=_blank href=\"$help_url\">here</a> for help with the chat.|$time|$nicetime\n") if($help_url);
    print(PASSWORD "From DarkChat:<b>Please</b> use the leave button to leave so your nick won't remain in use.|$time|$nicetime\n");
    $temp = (rand 10);
    system"cp $data_path/messages $data_path/$temp";
    open(OLD, "$data_path/$temp");
    open(NEW, ">$data_path/messages");
    print(NEW "Join:$username|$nicetime|$time|\n");
    while(<OLD>) { print(NEW "$_"); }
    close(NEW);
    close(OLD);
    unlink"$data_path/$temp";
}
  close(PASSWORD);
}

sub remove_user
{
  unlink"$data_path/users/$user";
  $blah = time;
  $temp = "$blah.$ENV{REMOTE_ADDR}";
  undef $blah;
  system"cp $data_path/messages $data_path/$temp";
  open(OLD, "$data_path/$temp");
  open(NEW, ">$data_path/messages");
  print(NEW "Leave:$user|$nicetime|$time|\n");
  while(<OLD>) 
  {
    chomp;
    ($nick,$msgtime,$realtime,$post) = split(/\|/,$_,4);
    print(NEW "$_\n") if(($realtime > $time-$keep) && ($nick ne ""));
  }
  close(NEW);
  close(OLD);
  unlink"$data_path/$temp";
}

sub reload
{
  $temp = (rand 10);
  system"cp $data_path/users/$username $data_path/users/$temp";
  open(OLD, "$data_path/users/$temp");
  open(NEW, ">$data_path/users/$username");
  while(<OLD>)
  {
    if($_ =~ /^Reload:/) { print(NEW "Reload:$nicetime\n"); }
    elsif($_ =~ /^Time:/) { print(NEW "Time:$time\n"); }
    else { print(NEW "$_"); }
  }
  close(OLD);
  close(NEW);
  unlink"$data_path/users/$temp";
}

sub list_users
{
  print"<table>\n";
  print"<th>Nickname</th><th>Last Load</th>\n";
  opendir(USERS, "$data_path/users");
  local(@users) = grep /^\w+$/, readdir USERS;
  closedir(USERS);
  foreach $user (@users)
  {
    open(INFO, "$data_path/users/$user");
    while(<INFO>)
    {
      chomp;
      ($option,$value) = split(/:/,$_,2);
      if($option eq "Time") { $lastime = $value; }
      elsif($option eq "Email") { $email = $value; }
      elsif($option eq "Reload") { $reload = $value; }
    }
    close(INFO);
    if($lastime < $time-$keep) { unlink"$data_path/users/$user"; }
    else
    {
      print"<tr><td>";
      if($email)
      {
        if($email =~ /^http:\/\//) { print"<a href=\"$email\">"; }
        else { print"<a href=\"mailto:$email\">"; }
      }
      print"$user";
      print"</a>" if($email);
      print"</td><td align=right>$reload</td>\n";
      undef $email;
    }
  }
  print"</table>\n";
}

sub private
{
  print"<INPUT type=hidden name=\"username\" value=\"$username\">\n";
  print"<INPUT type=hidden name=\"password\" value=\"$password\">\n";
  print"<CENTER>\n";
  if($title_graphic) { print"<img src=\"$title_graphic\" alt=\"$title\"><p>\n"; }
  else { print"<h2>$title</h2><p>\n"; }
  print"Private Message:<p>\n";
  print"<TEXTAREA name=\"message\" rows=5 cols=40 wrap=physical>$message</textarea><p>\n";
  print"Send to:<br>\n";
  opendir(DIR, "$data_path/users");
  local(@users) = grep /^\w+$/, readdir DIR;
  closedir(USERS);
  foreach $user (@users) { print"<input type=submit name=\"to_name\" value=\"$user\">\n" if($user ne $username); }
  print"<br>\n";
  print"<input type=submit name=\"action\" value=\"Back to Chat\">\n";
  print"<input type=reset value=\"Clear\">\n";
  print"</center>\n";
  print"<hr>\n";
  &show_private;
}

sub send_private
{
  $temp = (rand 10);
  # Add to recipient
  system"cp $data_path/users/$to_name $data_path/$temp";
  open(OLDTO, "$data_path/$temp");
  open(NEWTO, ">$data_path/users/$to_name");
  while(<OLDTO>)
  {
    chomp;
    if($_ eq "--NEW--") { print(NEWTO "$_\nFrom $username:$message|$time|$nicetime\n"); }
    else { print(NEWTO "$_\n"); }
  }
  close(NEWTO);
  close(OLDTO);
  unlink"$data_path/$temp";
  # Add to sender
  system"cp $data_path/users/$username $data_path/$temp";
  open(OLDFROM, "$data_path/$temp");
  open(NEWFROM, ">$data_path/users/$username");
  while(<OLDFROM>)
  {
    chomp;
    if($_ eq "--NEW--") { print(NEWFROM "$_\nTo $to_name:$message|$time|$nicetime\n"); }
    else { print(NEWFROM "$_\n"); }
  }
  close(NEWFROM);
  close(OLDFROM);
  unlink"$data_path/$temp";
  undef $message;
}

sub show_private
{
  print"Private Messages:<p>\n";
  print"<font color=\"$privcolor\">\n" if($privcolor);
  open(USER, "$data_path/users/$username");
  while(<USER>)
  {
    chomp;
    ($type,$data) = split(/:/,$_,2);
    if(($type =~ /^To/) || ($type =~ /^From/))
    {
      ($msgtext,$msgtime,$msgnice) = split(/\|/,$data,3);
      ($tofrom,$msgname) = split(/ /,$type,2);
      if($msgtext =~ /action{.*}/)
      {
        $msgtext =~ s/action\{/\<font color=$actioncolor\>$msgname\ /g if($tofrom eq "From");
        $msgtext =~ s/action\{/\<font color=$actioncolor\>$username\ /g if($tofrom eq "To");
        $msgtext =~ s/\}/<\/font>/g;
      }
      print"<img src=\"$chat_blt\">" if(($msgtime > $oldtime) && ($chat_blt));
      print"*NEW* " if(($msgtime > $oldtime) && ($chat_blt eq ""));
      print"$type at $msgnice:<br> $msgtext<hr>\n" if($msgtime > $time-$keep);
    }
  }
  close(USER);
  print"</font>\n" if($privcolor);
}

sub nice_time
{
  @newtime = localtime($usetime);
  foreach $part (@newtime) { $part = "0$part" if($part < 10); }
  $niceusetime = "$newtime[2]:$newtime[1]:$newtime[0]";
}
