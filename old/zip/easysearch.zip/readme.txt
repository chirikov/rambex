########################################################
#                                                      #
# EasySearch v1.2 by Thomas J. Delorme                 #
# E-mail : delorme@getperl.virtualave.net              #
# Created : Sunday, July 11, 1999                      #
# Revisions : See History Below                        #
#                                                      #
########################################################
#                                                      #
# HISTORY                                              #
#                                                      #
# Ver 1.0 - Base script released                       #
#           on Sunday, July 11, 1999                   #
#                                                      #
# Ver 1.1 - Friday, August 9, 1999                     #
#                                                      #
#         - Included 100 URL base.txt file to solve    #
#           empty database errors on some systems.     #
#                                                      #
# Ver 1.2 - Tuesday, February 8, 2000                  #
#                                                      #
#         - De-referenced un-used variables left over  #
#           from the development stages that were      #
#           causing errors on systems that             #
#           unconditionally ran the -w flag.           #
#                                                      #
########################################################
#
# WHAT THE SCRIPT DOES
# 
# EasySearch is a complete solution search engine that
# allows you to manage your own WWW search engine 
# easily! It features the following :
#
# 1. Complete full-function search engine with 
#    customizable index page.
#
# 2. Search options include words and phrases, as well
#    as a smut censor toggle.
#
# 3. Optional file-locking for a more secure database.
#
# 4. Allows visitors to add their URL and automatically
#    produces the correct form.
#
# 5. Three separate spam filters to prevent search engine
#    spammers.
#
# 6. Smut filter to censor adult material.
#
# 7. Customizable heading and footer for every page.
#
# 8. Customizable automated response sent to visitors
#    who submit their URLs.
#
# 9. Built-In New URLs page.
#
# 10. Built-In Random URL page.
#
#####################################################
#                                                   #
# This script was written for UNIX so I won't       #
# guarantee it's performance on other platforms.    #
#                                                   #
# See the easysearch.cgi file for more info on how  #
# to set it up to work with your server.            #
#                                                   #
# Once you have changed the variables in the script #
# to work with your server do the following :       #
#                                                   #
# 1. Upload easysearch.cgi into your cgi-bin.       #
#    (Be sure to set chmod to 755.)                 #
#                                                   #
# 2. Customize head.txt, foot.txt, respond.txt, and #
#    smut.txt to your liking and make sure all      #
#    links in index.html point to the correct links #
#    for your server. (Mainly just the menu items   #
#    which you may have to adjust in head.txt as    #
#    well.                                          #
#                                                   #
# 3. Upload head.txt, foot.txt, respond.txt,        #
#    base.txt, smut.txt, and index.html to a        #
#    directory of your choosing.                    #
#    (Be sure to set chmod to 777 on all of them    #
#    except index.html.)                            #
#                                                   #
# I hope this script brings you lots of traffic!    #
#                                                   #
################   THAT'S IT!   #####################

