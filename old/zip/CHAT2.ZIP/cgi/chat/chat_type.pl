sub return_type {
@online      =&readtxtfile($onlinefile,2);
@online      =sort @online;
@addwordcolor=&readtxtfile($addwordcolorfile) if ($userlevel>=$level_addwordcolor);

print "<html><head><title>type</title>\n";
print "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1251\">\n";
print "<script Language='JavaScript'>\n";
$temp="";
if ($userlevel>=$level_private) {$temp=" document.forms[0].towhoway.checked=false;"};
print <<SCR;
function ClearText() {
 document.forms[0].says.value='';
 $temp
 return true;
}
SCR
print "function FocusText() {\n";
print "  document.forms[0].says.focus();\n";
print "  document.forms[0].says.select();\n";
print "  return true;\n";
print "}\n";
print "function checksays() {\n";
print "  if (checkempty(document.forms[0].says.value)==false) {\n";
print "     alert('������� ����, ���-������!');\n";
print "     return false;\n";
print "  }\n";
print "  self.status='SENT';\n";
print "  FocusText();\n";
print "  return true;\n";
print "}\n";
print "function checkempty(txtval){\n";
print "  if (txtval.length==0)\n"; 
print "     return false;\n";
print "  var i=0;\n";
print "  while (i<txtval.length) {\n";    
print "     if (txtval.substring(i,i+1) != '')\n"; 
print "        return true;\n";
print "     i=i+1;\n";
print "  }\n";
print "  return false;\n";
print "}\n";
print "</script>\n";
print "</head><body $stdbgimg bgcolor=$typeback text=$typeword onLoad='return FocusText();'>\n";
print "<div align=left>\n";
print "<form method=POST action='$cgiurl?cf=says$userinfo' target='message' onsubmit='return(checksays());'>\n";
print "$username : <input type=text   name='says' size=40 maxlength=450> \n";
print "<font color=#000000><input type=submit value='�������'>\n";

local($temp1)="";

if ($userlevel>=$level_addwordcolor) {
   srand;
   $ram=int(rand($#addwordcolor+1));
   local($temp)=0;
   print "<select name='addwordcolor'>\n";
   foreach (@addwordcolor) {
      if (($userlevel<2) || ($color eq "000000")) {
         $_ =~ s/>/ selected>/g if ($temp eq $ram);
      } else {
         $_ =~ s/>/ selected>/g if ($_=~/$color/);
      }
      print "$_";
      $temp++;
   } 
   print "</select></font><br>\n";
}

if ($userlevel>=$level_private) {
print "<input type=checkbox name='towhoway' value='private'";
print ">�������\n";
}
print "<input type='hidden' name='towho' value=''>\n";
print "<input type='hidden' name='toidt' value=''>\n";
print "<font color=#000000><input type=button value='��������' onClick='return ClearText();'></font><br>\n";
print "</form>";
print "</div></body></html>";
}
