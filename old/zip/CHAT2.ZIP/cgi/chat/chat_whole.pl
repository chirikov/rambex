sub return_whole {
$userinfo="$userinfo&key=$KEY";
$userinfo="$userinfo&idt=$IDT";

print "<html><head><title>$roomtitle</title>\n";
print "<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=windows-1251\">\n";
print "</head>\n";
print "<script language=\"JavaScript\">\n";
print "<!--\n";
print "\n  chatcgi=\"$cgiurl?\"\n\n";
@html=&readtxtfile($wholefile,2);
foreach (@html) {   
	print "$_";
}
print "\n var idt=\"$IDT\";\n";
print "var key=\"$KEY\";\n";
print "var room=\"$ROOMW\";\n";
#$temp=$username;
#$temp=~s/�/\\�/g;
$temp=&StrToHex($username);
print "var hexname=\"$temp\";\n";
print <<HTML;
var username="$username";
HTML

print "GetMail(\"true\");\n" if ($msgalert eq "true");

print "//-->\n</script>\n";
$c1="170";
$c2="90";
$c3="100";
$c3="95" if ($room eq "er");
$c4="30";

print "<frameset cols='*,$c1' border=1 frameborder=1 framespacing=0 bordercolor=gray>\n";
print "   <frameset rows='$c4,*,$c2' border=1 frameborder=1 framespacing=0 bordercolor=gray>\n";
print "      <frame src='$cgiurl?cf=up$userinfo' name='up' scrolling=no noresize>\n";
print "      <frame src='$cgiurl?cf=look$userinfo'    name='message'>\n";
print "      <frame src='$cgiurl?cf=settype$userinfo' name='type'  marginwidth=0>\n";
print "   </frameset>\n";
print "   <frameset rows='*,$c3' border=$resize frameborder=$resize framespacing=$resize>\n";
print "      <frame src='$cgiurl?cf=online$userinfo'  name='online' marginwidth=0>\n";
print "      <frame src='$cgiurl?cf=setfunc$userinfo' name='func'   marginwidth=0>\n";
print "   </frameset>\n";
print "</frameset>\n";
print "</html>\n";
}
