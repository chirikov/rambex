sub return_func {
print "<html><head><title>Func</title>\n";
print "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1251\">\n";
print "<link rel='stylesheet' TYPE='text/css' HREF='$cssurl'>\n";
print "</head>\n";
print "<body $stdbgimg bgcolor=$funcback text=$funcword vlink=#FFFF00 link=#FFFF00 alink=#FF0000><center>";
print "<br>";
print "[<a href=$cgiurl?cf=look$userinfo target='message'>��������</a>]<br>";
print "[<a href=$cgiurl?cf=chinf$userinfo target='_blank'>����</a>]<br>" if ($userlevel>1);
print "[<a href=javascript:parent.SendMail('true')>���������</a>]<br>" if ($userlevel>1);
print "[<a href=$cgiurl?cf=logout$userinfo$changelogouturl target='_top'>�����</a>]<br>";
print "</center></body></html>";
}

sub return_up{
print <<HTML;
<html><head><title>Func</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<link rel='stylesheet' TYPE='text/css' HREF='$cssurl'>
</head>
<script language="JavaScript">
<!--
function OpenUrl(oUrl){
  window.open(oUrl,"oUrl","toolbar=0,location=0,directories=0,status=0,menubar=0,scrollbars=1,resizable=1");
}
//-->
</script>
<body $stdbgimg bgcolor=$funcback text=$funcword vlink=#FFFF00 link=#FFFF00 alink=#FF0000 topmargin=0>
<table border="0" cellpadding="0" cellspacing="0" width="100%" height="100%">
  <tr>
    <td width="100%"><p align="center"><font face="MS Sans Serif" size="2"><strong>
[<a href=javascript:OpenUrl("$cgiurl?cf=any&f=news")>�������</a>]&nbsp;&nbsp;
    [<a href=javascript:OpenUrl("$cgiurl?cf=wall")>�����</a>]&nbsp;&nbsp; [<a href=javascript:OpenUrl("$cgiurl?cf=any&f=help")>������</a>]&nbsp;&nbsp; [<a href=javascript:OpenUrl("$cgiurl?cf=any&f=rules")>�������</a>]
&nbsp;&nbsp;[<a href=http://www.guestbook.ru/book.cgi?user=shchat&action=show&language=Russian target=_blank>�������� �����</a>]
</strong></font></td>
  </tr>
</table>
</body></html>
HTML
}

sub Get_Any{
   $mode=&get_var('f','\n|"|<|>|\&|;| |\?|��');

   $tmp_file=$news_file;
   $msg2="�������� ���!";
   $msg1="�������";
   if ($mode eq "help"){
       $tmp_file=$help_file;
       $msg2="������ ���!";
       $msg1="������";
   }
   if ($mode eq "rules"){
       $tmp_file=$rules_file;
       $msg2="������ ���!";
       $msg1="�������";
   }

   if (-e "$filehead$tmp_file") {
      @af=&readtxtfile("$tmp_file");

      $dl="";
      foreach (@af) {
          $temp=$_;
	  $temp=~s/\n//g;
          $dl="$dl$temp";
      }
     $dl="$dl<br><br><p align=right><small>CGI WEB CHAT<br>$chatversion<br>mailto:<a href=mailto:webmaster\@er.agava.ru>Webmaster of Russian ER site.</a></p></small>";
     &default_html("$adv$msg1","$dl");
   } else {
     &default_html("$msg2");
   }
}
