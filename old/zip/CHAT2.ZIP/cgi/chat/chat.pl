#!/usr/bin/perl
##############################################################################
# SetUp Begin
# Path Setup
# based on evilchat
# CopyRight By EastWood 2000(C) mailto:webmaster@er.agava.ru
# please visit:
#     http://er.agava.ru/                   - Russian ER page
#     http://shadrinsk.unets.ru/chat/       - Shadrinsk's chat copyright be eastwood
#     http://shadrinsk.zaural.ru/~eastwood/ - My Home Page
# �������� ���� ��� ����.

$cgipath          = "D:/WWW/cgi/chat/";             # location scripts file's
$filehead         = "D:/SHDATA/chat/files/";        # location *.txt file's
$basehead         = "D:/SHDATA/chat/base/";         # location base file's

#$cgipath          = "";
#$filehead         = "../../data/files/";           # location *.txt file's
#$basehead         = "../../data/base/";            # location base file's


#$osname		  = "UNIX";                # UNIX for Unix and Linux
$osname		  = "WIN95";                       # UNIX for Unix and Linux

@banlist="";
# URL's Setup

$adminpswd = "your_password";
$cgiurl    = "/cgi-bin/chat/chat.pl";    # URL of chat.cgi
$htmlurl   = "/chat/";                   # Document's URL
$logouturl = "/chat/";                   # URL after logout
$imageurl  = "images/";                  # URL htmlurl + imageurl
##############################################################################



$css       = "css/default.css";                    # CSS
$cssurl    = "$htmlurl$css";                       # Style Sheet url
$chatversion         = "Version 4.07.2000b by EastWood for Courier Plus 07.05.2000";

$cgi_write_online    = "chat_write_online.pl";    #  01
$cgi_write_message   = "chat_write_message.pl";   #  02
$cgi_whole           = "chat_whole.pl";           #  03
$cgi_logout          = "chat_logout.pl";          #  04
$cgi_return_message  = "chat_return_message.pl";  #  05
$cgi_return_online   = "chat_return_online.pl";   #  06
$cgi_admin           = "chat_admin.pl";           #  07
$cgi_type            = "chat_type.pl";            #  09
$cgi_func            = "chat_func.pl";            #  10
$cgi_messageshow     = "chat_messageshow.pl";     #  11
$cgi_check_ban       = "chat_check_ban.pl";       #  12
$cgi_wall            = "chat_wall.pl";            #  13
$cgi_base            = "chat_base.pl";            #  14


$onlinefile       = "online.txt";
$messagefile      = "message.txt";
$addwordcolorfile = "addwordcolor.txt";
$banlistfile      = "banlist.txt";
$wallfile         = "wall.txt";
$wholefile        = "whole.txt";
$datafile         = "data.txt";
$vatafile	  = "vata.txt";
$help_file        = "help.txt";
$news_file        = "news.txt";
$rules_file       = "rules.txt";
$adverfile        = "";
$lock_file_online = "lock1.tmp";
$lock_file_message= "lock2.tmp";

$lock_file        = $lock_file_online;

$gifhead          = "$htmlurl$imageurl"; # URL of "*.gif".
$stdbgimg         = "";
         
$messageback = "#000000"; # Background color of message's area.
$messageword = "#408080"; # Text color of message's area.
$onlineback  = "#000044"; # Background color of online's area.
$onlineword  = "#ffffff"; # Text color of online's area.
$typeback    = "#000044"; # Background color of typing area.
$typeword    = "#ffffdd"; # Text color of typing area.
$funcback    = "#000044"; # Text color of panel's area.
$funcword    = "#ffffdd"; # Background color of panel's area.
$loginword   = "#DDDDDD"; # Login color.
$logoutword  = "#DDDDDD"; # Logout color.
$uptitle="<center><font color=#808080>������ ���� + ��� + ��������!</font></center><br>";

$usersexmust      = 0;   # Visitor must select gender. 1=ENABLE 0=DISABLE
$resize           = 0;   # Resize the frame. 1=ENABLE 0=DISABLE
$reloadmsg        = 15;  # Refreash the screen.
$reloadonl        = 25;  # Refreash the online section.
$addsign_size     = 4;   # Size of icon.
$allow_sex1       = 1;   # User's gender appear in online area. 1=ENABLE 0=DISABLE
$allow_sex2       = 0;   # User's gender appear in messageboard. 1=ENABLE 0=DISABLE 
$allow_time       = 1;   # Timing in messageboard. 1=ENABLE 0=DISABLE
$allow_message    = 50;  # Maxium message per page,
$max_wall_message = 20;  # Max message on wall
$one_show_wall    = 5;   # ����� �� ���� ��� ��������� �� ����� ����������.
$time_miss        = +0;  # TimeZone adjustment.
$dayleft	  = 5;   # Day of keep log file.

$level_addwordcolor= 1;  # Allows user to change the message's color. 1=ENABLE 0=DISABLE
$level_private     = 2;  # Allows user to use "whisper". 1=ENABLE 0=DISABLE
$level_html        = 3;  # Allows user to use HTML. 1=ENABLE 0=DISABLE
$level_seelevel    = 3;  # Allows user to see the level. 1=ENABLE 0=DISABLE
$level_seeip       = 3;  # Allows user to see IP. 1=ENABLE 0=DISABLE
$level_addban      = 3;  # Allows user operate with ban list. 1=ENABLE 0=DISABLE
$level_seeprivate  = 4;  # Allows user to see "Whispers". 1=ENABLE 0=DISABLE


$allow_messagerecord = 0; # Archive 1=On 0=Off
$reloadx           = 15;  # 

$usersexcolor{"�������"}  = "00FFFF";  #User Sex Color
$usersexcolor{"�������"} = "FF8080";

$roomtitle = "��������"; # Name of chatroom

$msgalert="false";
$temp1=&GetRandNum;
$adv="<center>
<!-- Russian LinkExchange code START -->
  <iframe
  src=http://www.linkexchange.ru/cgi-bin/erle.cgi?26362?$temp1
  frameborder=0 vspace=0 hspace=0 width=468 height=60
  marginwidth=0  marginheight=0 scrolling=no>
  <a href=http://www.linkexchange.ru/users/026362/goto.map target=_top>
  <img src=http://www.linkexchange.ru/cgi-bin/rle.cgi?26362?$temp1
  alt=\"RLE Banner Network\" border=0 height=60 width=468></a>
  </iframe><br>
<!-- Russian LinkExchange code END -->
</center><br>
";
# SetUp End
#############
$|=1;

print "Content-type: text/html;CHARSET=windows-1251\n";
print "Pragma:no-cache\n";

$userlevel =1;
$allow_html=0;
$exist     ="no";
$nextid    ="";
$KEY       ="";
$IDT       ="";

######################
## Get Cookie    
$cookie="false";
$envname="COOKIE"; # for WIN95
$envname="HTTP_COOKIE" if ($osname eq "UNIX");
$cook=$ENV{$envname};
@cook2=split(/[= ;]/,$cook);
for$i(0..@cook2) {if($cook2[$i] eq 'SHCHAT'){$cookie=$cook2[$i+1];}}
$cookie=~s/\|//g;
$cookie=~s/\n//g;
######################

$userip = $ENV{'REMOTE_ADDR'};
$proxyip = $userip;
$proxy="false";
$realip="";
$realip = $ENV{'HTTP_X_FORWARDED_FOR'};
if ($realip ne "") {
         $proxy="true";
         $realip=~s/ //g;
         @rip=split(",",$realip);
         $userip=@rip[$#rip];
}

do "$cgipath$cgi_check_ban";
if (&check_ban eq "yes") { 
   &error("�� �� ������ �������� ���������� �� ����!<br>��� �������� ������ $who $chkdate �� �������: $chkreason");
   exit;
}

&get_form;
&set_var;
#$mmm=$username;
#$mmm=~ tr/a-z/A-Z/;$mmm=~ tr/�-�/�-�/;
#$mmm=&StrToHex($mmm);
$mmm=&GetRandKey(21);
if (($cf eq "login") && ($cookie eq "false")){
   print "Set-Cookie: SHCHAT=$mmm; path=/; expires=Wednesday, 08-Dec-19 23:59:59 GMT;\n"; 
   $cookie=$mmm;
}
print "\n";

if ($cf eq "reaction") {
   do "$cgipath$cgi_write_online";
   do "$cgipath$cgi_admin";
   &get_user_info;
   if ($exist eq "no") {&chanalerror}
   if ($userlevel<3) {&chanalerror;}
   &reaction;
   exit;
}
elsif ($cf eq "wall") {
   do "$cgipath$cgi_wall";
   &pwall($walljob);
   exit;
}
elsif ($cf eq "login") {
   do "$cgipath$cgi_write_online";
   do "$cgipath$cgi_write_message";
   do "$cgipath$cgi_whole";
   &ReadData;
   $KEY=&GetRandKey;
   $IDT=$nextid;
   &write_online("online"); 
   &write_message("login") if ($exist eq "no"); 
   &return_whole;
   &WriteData;
   exit;
}
elsif ($cf eq "logout") {
   do "$cgipath$cgi_write_online";
   do "$cgipath$cgi_write_message";
   do "$cgipath$cgi_logout";
   &write_online("outline");
   if ($exist eq "no") {&chanalerror}
   &write_message("logout") if ($exist ne "no"); 
   &return_logout; 
   exit;
}
elsif ($cf eq "look") {
   do "$cgipath$cgi_return_message";
   do "$cgipath$cgi_write_online";
   &write_online(online);
   if ($exist eq "no") {&chanalerror}
   &return_message; 
   exit;
}
elsif ($cf eq "says") {
   do "$cgipath$cgi_write_online";
   do "$cgipath$cgi_write_message";
   do "$cgipath$cgi_return_message";
   &write_online(online);
   if ($exist eq "no") {&chanalerror}
   $says  =&get_var('says'           ,'\n|��');
   &write_message("says");
   &return_message;
   exit;
}
elsif ($cf eq "online") {
   do "$cgipath$cgi_write_online";
   do "$cgipath$cgi_return_online";
   &get_user_info;   
#   &write_online(online);
   if ($exist eq "no") {&chanalerror}
   &return_online;
   exit;
}
elsif ($cf eq "banip") {
   do "$cgipath$cgi_admin";
   do "$cgipath$cgi_write_online";
   do "$cgipath$cgi_return_online";
   &get_user_info;
   if ($exist eq "no") {&chanalerror}
   &write_ban;
   &return_online;
   exit;
}
elsif ($cf eq "uban") {
   do "$cgipath$cgi_admin";
   do "$cgipath$cgi_write_online";
   do "$cgipath$cgi_return_online";
   &get_user_info;
   if ($exist eq "no") {&chanalerror}
   &write_uban;
   &return_online;
   exit;
}
elsif ($cf eq "settype") {
   do "$cgipath$cgi_type";
   do "$cgipath$cgi_write_online";
   &get_user_info;
   if ($exist eq "no") {&chanalerror}
   &return_type;
   exit;
}
elsif ($cf eq "setfunc") {
   do "$cgipath$cgi_func";
   do "$cgipath$cgi_write_online";
   &get_user_info;
   if ($exist eq "no") {&chanalerror}
   &return_func; 
   exit;
}elsif ($cf eq "up") {
   do "$cgipath$cgi_func";
   &return_up; 
   exit;
}elsif ($cf eq "Info") {
   do "$cgipath$cgi_write_online";
   &get_user_info;
   if ($exist eq "no") {&chanalerror}
   &get_Info_html; 
   exit;
}
elsif ($cf eq "chinf") {
   do "$cgipath$cgi_write_online";
   do "$cgipath$cgi_base";
   &get_user_info;
   if ($exist eq "no") {&chanalerror}
   if ($userlevel<2) {&error("�� �� ����������������.");}
   &Info_For_Change; 
   exit;
}
elsif ($cf eq "change") {
   do "$cgipath$cgi_write_online";
   do "$cgipath$cgi_base";
   &get_user_info;
   if ($exist eq "no") {&chanalerror};
   if ($userlevel<2) {&error("�� �� ����������������.");}
   &change_reg; 
   exit;
}
elsif ($cf eq "sndmail") {
   do "$cgipath$cgi_write_online";
   do "$cgipath$cgi_base";
   &get_user_info;
   if ($exist eq "no") {&chanalerror};
   if ($userlevel<2) {&error("�� �� ����������������.");}
   &get_sndmail_html;
   exit;
}
elsif ($cf eq "set") {
   do "$cgipath$cgi_write_online";
   do "$cgipath$cgi_base";
   &get_user_info;
   if ($exist eq "no") {&chanalerror};
   if ($userlevel<2) {&error("�� �� ����������������.");}
   &set_mail;
   exit;
}
elsif ($cf eq "gm") {
   do "$cgipath$cgi_write_online";
   do "$cgipath$cgi_base";
   &get_user_info;
   if ($exist eq "no") {&chanalerror};
   if ($userlevel<2) {&error("�� �� ����������������.");}
   &get_mail;
   exit;
}elsif ($cf eq "alluser") {
   do "$cgipath$cgi_base";
   &Return_All_Users;
   exit;
}


&chatversionhtml;
exit;
###########
sub get_form {
@querys = split(/&/, $ENV{'QUERY_STRING'});
foreach (@querys) {
  ($name,$value) = split(/=/, $_);
  $value = &filterhtml($value);
  &setvaluetoform($name, $value); 
}

read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
@pairs = split(/&/, $buffer);
foreach (@pairs) {
  ($name, $value) = split(/=/, $_);
  $value =~ tr/+/ /;
  $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

  &setvaluetoform($name, $value); 
}
}
##########
sub filterhtml {
local($return)=$_[0];
$return =~ s/<!--(.|\n)*-->//g;
if ($allow_html != 1) {
$return =~ s/</\&lt;/g;
$return =~ s/>/\&gt;/g;

#$value =~ s/\&/aM;/g;
#   $return =~ s/<([^>]|\n)*>//g;
   $return =~ s/<//g;
}
return $return;
}
##########
sub setvaluetoform {
if ($FORM{$_[0]}) {
   $FORM{$_[0]}="$FORM{$_[0]}��$_[1]";
}
else {
   $FORM{$_[0]}=$_[1];
}
}
##########
sub set_var {
($secn,$minn,$hourn,$dayn,$monn,$yearn,$weekn,$yeardayn,$isdst) = localtime(time+(3600*$time_miss));
  $monn=$monn+1;
  if ($monn<10)  {$monn="0$monn";}
  if ($dayn<10)  {$dayn="0$dayn";}
  if ($hourn<10) {$hourn="0$hourn";}
  if ($minn<10)  {$minn="0$minn";}
  if ($secn<10)  {$secn="0$secn";}
  $yearn=1900+$yearn;
  $daten="$dayn.$monn.$yearn";
  $timen="$hourn\:$minn\:$secn";
  $secn=$hourn*60*60+$minn*60+$secn;

  $todaylogfile="$dayn$monn$yearn.log";
  &NDayAgo($dayleft);
  $leftlogfile="$dayl$monl$yearl.log";

  $uponline="<font face=Arial size=2><strong>������� $daten � � ����:</strong></font></center>";
  $roomp="";
  $ROOMW="";

  $cf              =&get_var('cf','\n|��');
  &chatversionhtml if ($cf eq "");

  $room             =&get_var('room','\n|��');
  if ($room eq "er") {
        &ER_Init;
  }

  if ($cf eq "gah") {
         do "$cgipath$cgi_admin";
         &get_admin_html;
	 exit;
  }

  if ($cf eq "any") {
         do "$cgipath$cgi_func";
         &Get_Any;
         exit;
  }


  if ($cf eq "doadmin") {
         do "$cgipath$cgi_admin";
         &Do_Admin;
	 exit;
  }

  if ($cf eq "newreg") {
         do "$cgipath$cgi_base";
         &new_reg;
	 exit;
  }

  if ($cf eq "infoabout") {
         do "$cgipath$cgi_base";
         $user = &get_var('usern','\n|��');
         $user=~ tr/a-z/A-Z/;$user=~ tr/�-�/�-�/;
         &Return_Reg_Info($user);
	 exit;
  }

  if ($cf eq "regfm") {
	do "$cgipath$cgi_base";         
	&Registration;	 
	exit 0;
  }


  $username         =&get_var('username'       ,'\n|"|<|>|\&|;| |\?|��');
  if ($cf eq "login") {
      $color="000000";
      $mode         =&get_var('mode'           ,'\n|��');
      $username=~s/ /_/g;
      $username=substr($username,0,15);
      if ($mode eq "user") {
         $usersex          =&get_var('usersex'        ,'\n|��');
      } 
      elsif ($mode eq "reg") {
         $usersex="";
         $userpass=&get_var('password','\n|��');
         do "$cgipath$cgi_base";
         $temp3=$username;
         $temp3=~ tr/a-z/A-Z/;$temp3=~ tr/�-�/�-�/;
         $temp4=&ReadInfoForReg($temp3);
         if ($temp4 ne "NOFILE") {
            if ($bspass1 eq $userpass){
                $userlevel =2;
                $userlevel =3 if ($bspr eq "K");
                $userlevel =4 if ($bspr eq "M");
                $color=$bscolor;
                $color="000000" if ($color eq "emp"); 
                $usersex="�������" if ($bspol eq "�");
                $usersex="�������" if ($bspol eq "�");
                $bsdate=$daten;$bstime=$timen;$bsip=$userip;
		&write_stat($temp3);
                $e=".msg";
                $temp1="z$numberfile$e";
                if (-e "$filehead$temp1") {$msgalert="true";}
           } elsif ($bspass1 ne $userpass) { &error("������ ���������!"); }
         } 
      }
  }

  $towhoway         =&get_var('towhoway'       ,'\n|��');
  $towho            =&get_var('towho'          ,'\n|��');

  $addwordcolor     =&get_var('addwordcolor'   ,'\n|��');
  $changelogouturl  =&get_var('changelogouturl','\n|��');
  $KEY              =&get_var('key'            ,'\n|��');
  $IDT              =&get_var('idt'            ,'\n|��');
  $IDT2             =&get_var('toidt'          ,'\n|��');
  $UNAME            =&get_var('uname'          ,'\n|��');

  if ($cf eq "wall") {
    $walljob="show";
    $walljob =&get_var('walljob','\n|��');
    if ($walljob eq "sign") {
      $name    =&get_var('name','\n|��');
      $email   =&get_var('email','\n|��');
      $message =&get_var('message','��');
      &checkempty($name,"�� ������ ���.");
      &checkempty($message,"��� ���������.");
      $name    =&filterhtml($name);
      $email   =&filterhtml($email);
      $message =&filterhtml($message);
      $message=~ s/\n/<br>/g;
    }
  }

  $addwordcolor=&filterhtml($addwordcolor);

  if ($cf ne "wall"){
    &checkempty($username,"�� ���������� ���.");
    &checkempty($usersex ,"No Usersex") if ($usersexmust==1); 
#    &checkempty($says    ,"������� ���� ���-������ !!!")    if ($cf eq "says");
  }

  $reloadtimes=4;
  $reloadxx=$reloadx*$reloadtimes;
  $reloadxxx=$reloadxx*$reloadtimes;
  $randim=&GetRandKey();
  $randim="&rand=$randim";
  $userinfo="&username=$username$roomp$randim";
  $userinfo="$userinfo&key=$KEY" if ($cf ne "login");
  $userinfo="$userinfo&idt=$IDT" if ($cf ne "login");
}

#########
sub get_var {
  local($return)="";
  $return="$FORM{$_[0]}" if ($FORM{$_[0]});
  $return=~ s/$_[1]//g;
  $return=~ s/\|//g;
  $return = &filterhtml($return);  
  return $return;
}
#########
sub readtxtfile {
  &check_lock(25) if ($_[1] eq "true");
  if (!open(READTXTFILE,"$filehead$_[0]")) {$err++;}
  @readtxtfile=<READTXTFILE>;
  close(READTXTFILE);
  &clean_up if ($_[1] eq "true");
  return @readtxtfile;
}
#############
sub check_lock {
   $time = $_[0];

   for ($i = 1;$i <= $time; $i++) {
      if (-e "$filehead$lock_file") {
         sleep 1;
      }
      else {
         open(LOCK,">$filehead$lock_file");
         print LOCK "0";
         close(LOCK);
         last;
      }
   }
}

sub clean_up {
   unlink("$filehead$lock_file");
}
#############
sub checkempty {
  local($chkval)=$_[0];
  $chkval =~ s/ |<br>|\n//g;
  &error($_[1]) if ($chkval eq "");
}
#############
sub error {
  print "\n";
  print "<html><head><title>$roomtitle error</title>\n";
  print "</head><body bgcolor=$messageback text=$messageword>\n";
  print "<center><h1>������ !</h1><h2>$_[0]</h2></center>\n";
  print "</body></html>\n";
  exit 0;
}
#############
sub default_html {
  print "\n";
  print "<html><head><title>$roomtitle</title>\n";
  print "</head><body bgcolor=$onlineback text=$onlineword>\n";
  print "<center><h2>$_[0]</h2></center>\n";
  print "$_[1]" if $_[1];
  print "</body></html>\n";
  exit 0;
}
#############
sub chanalerror {
  print "<html><head><title>$roomtitle error</title>\n";
  print "</head><body bgcolor=$messageback text=#FFFFDD vlink=#FFFF00 link=#FFFF00 alink=#FF0000>\n";
  print "<center><hr><h2>������ !</h2><h3>��� ��� � ������ ������!<br>\n";
  print "��������� �������: ������ �����.</h3>\n";
  print "����������� � ���.\n";
  print "<br> [<a href=\"$htmlurl\" target=\"_top\">���������</a>]\n";
  print "</center>\n";
  print "</body></html>\n";
  exit 0;
}
#############
sub GetRandKey{
  if ($_[0]) {$pc=$_[0];} else {$pc=11;}
  @BB1=('0','1','2','3','4','5','6','7','8','9','A','a','B','b','C','c'
  ,'D','d',,'E','e','F','f','G','g','H','h','I','i','J','j','K','k','L'
  ,'l','M','m','N','n',,'O','o','P','p','R','r','S','s','T','t','U','u'
  ,'V','v','W','w','X','x','Y','y','Z','z','0','1','2','3','4','5','6'
  ,'7','8','9');
  srand;
  $temp="";
  for($i=1;$i<$pc;$i++){
    $val = rand(@BB1);
    $temp="$temp$BB1[$val]";
  }
  return $temp;
}

sub GetRandNum{
  @BB1=('0','1','2','3','4','5','6','7','8','9','0','1','2','3','4','5','6'
  ,'7','8','9');
  srand;
  $temp="";
  for($i=1;$i<12;$i++){
    $val = rand(@BB1);
    $temp="$temp$BB1[$val]";
  }
  return $temp;
}

sub ReadData{
   @data=&readtxtfile($datafile);
   $nextid=$data[0];$nextid=~ s/\n//g;
   $lastm=$data[1];$lastm=~ s/\n//g;
   if ($minn>$lastm+2){
      do "$cgipath$cgi_write_message";
      @vata=&readtxtfile($vatafile);
      $val = rand(@vata);
#      $temp=$hourn-2;
#      $says="���������� ����� $temp\:$minn. ���!";
      $says=$vata[$val];
      $says=~ s/\n//g;
      &write_message(server);
   }
}

sub WriteData{
   $nextid++;
   open(DATAF,">$filehead$datafile");
   print DATAF "$nextid\n";
   print DATAF "$minn\n";
   close(DATAF);
}

sub StrToHex{
   $rethex=unpack("H*",$_[0]);
   $rethex=~ tr/a-z/A-Z/;
   return  $rethex;
}

sub geticonname {
  @icons=readtxtfile("icons.txt",2);
  foreach (@icons) {
   ($insfile,$insname)=split(/\|/,$_);
     if ($insname eq $_[0]) {
        return $insfile;
     }
  }
  return "icons/emb";
}

sub chatversionhtml {
  print "\n";
  print "<html><head><title>$roomtitle - CGI CHAT ������.</title>\n";
  print "<link rel='stylesheet' TYPE='text/css' HREF='$cssurl'>\n";
  print "</head><body $stdbgimg bgcolor=$messageback text=#FFFFDD vlink=#FFFF00 link=#FFFF00 alink=#FF0000>\n";
  print "<center><hr><h2>CGI WEB ���!</h2><h3>$chatversion \&copy;<br>\n";
  print "<a href=\"mailto:webmaster\@er.agava.ru\">mailto:webmaster\@er.agava.ru</a></h3>\n";
  print "<br> [<a href=\"$htmlurl\" target=\"_top\">����� � ���</a>]\n";
  print "</center>\n";
  print "</body></html>\n";
  exit 0;
}

sub ER_Init{
  $m="12511";
}

sub banlist_html{
print <<HTML;
<html><head><title>$roomtitle ������������� BANLIST!</title>
</head><body $stdbgimg bgcolor=$onlineback text=$onlineword vlink=#00FFFF link=#00FFFF alink=#00FFFF>
<table border="0" cellpadding="0" cellspacing="0" width="100%">
  <tr>
    <td width="16%" bgcolor="#008080"><p align="center"><font face="MS Sans Serif" size="1"
    color="#FFFF00"><strong>���</strong></font></td>
    <td width="16%" bgcolor="#008080"><p align="center"><font face="MS Sans Serif" size="1"
    color="#FFFF00"><strong>����</strong></font></td>
    <td width="17%" bgcolor="#008080"><p align="center"><font face="MS Sans Serif" size="1"
    color="#FFFF00"><strong>�����</strong></font></td>
    <td width="17%" bgcolor="#008080"><p align="center"><font face="MS Sans Serif" size="1"
    color="#FFFF00"><strong>������</strong></font></td>
    <td width="17%" bgcolor="#008080"><p align="center"><font face="MS Sans Serif" size="1"
    color="#FFFF00"><strong>IP</strong></font></td>
    <td width="17%" bgcolor="#008080"><p align="center"><font face="MS Sans Serif" size="1"
    color="#FFFF00"><strong>UNBUN</strong></font></td>
  </tr>
HTML

$k=0;
@bl=&readtxtfile($banlistfile);
@bl=sort @bl;
foreach(@bl) {
   ($chkuserip,$chkcook,$kname,$chkdate,$chkreason,$who,$end) = split(/\|/,$_);
   print "<tr>";
   print "<td width=16% align=center>$who</td>\n";
   print "<td width=16% align=center>$kname</td>\n";
   print "<td width=16% align=center>$chkdate</td>\n";
   print "<td width=16% align=center>$chkreason</td>\n";
   $temp1=$chkuserip;
   if ($chkuserip eq "0.0.0.0"){
       $temp1="�� ����";
   }
   print "<td width=16% align=center>$temp1</td>\n";
   print "<td width=16% align=center>[<a href=$cgiurl?cf=reaction$userinfo\&func=unban\&nk=$k target=_top>UnBan</a>]</td>\n";
   print "</tr>";
   $k++;
}
print "</table></body></html>";
}

sub unban{
$k=0;
@bl2=@banlist;
@bl2=sort @bl2;
open(BANLIST,">$filehead$banlistfile") || die $!;
foreach(@bl2) {
   if ($k!=$_[0]){
      print BANLIST "$_";
   }
   $k++;
}
close(BANLIST);
}

sub NDayAgo{
@DD=('31','31','28','31','30','31','30','31','31','30','31','30','31');
$monl=$monn;
$dayl=$dayn-$_[0];
$dayl="0$dayl" if (($dayl<10) && ($dayl>0));
$yearl=$yearn;
if ($dayl<1) {
	$dayl=$DD[$monl-1]+$dayl;
	$monl=$monl-1;
	if ($monl<1) {
            $monl=12+$monl;
	    $yearl=$yearl-1;
	}
        $monl="0$monl" if ($monl<10);
}
}

###########################################################################
#chat
###########################################################################