sub init_var {
   $wallbgcolor="#000000";
   $walltextcolor="#FFFFDD";
   $wallvlink="#FFFF00";
   $wallalink="#FF0000";   
   $walllink="#FFFF00";
   $tableback="#393939";
   $walldocend="";
}

sub return_wall{

@wall=&readtxtfile($wallfile,2);
print "<html><head><title>$roomtitle - ����� ����������</title>\n";
print "<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=windows-1251\">\n";
print "<link rel='stylesheet' TYPE='text/css' HREF='$cssurl'>\n";
print "</head><body $stdbgimg bgcolor=$wallbgcolor text=$walltextcolor alink=$wallalink vlink=$wallvlink link=$walllink>\n";
print "$adv\n";
$msgcount=$#wall;
if ($msgcount>=$max_wall_message){
  open(WWALL,">$filehead$wallfile") || die $!;
  flock(WWALL,2) if ($osname eq "UNIX"); 
  for($i=$#wall-$max_wall_message+1;$i<$#wall+1;$i++) {
     print WWALL "$wall[$i]";     
  }
  flock(WWALL,8) if ($osname eq "UNIX"); 
  close(WWALL);
}

$mm="";
$mm="&usr=$username" if ($username ne "");
print "<h2 align=\"center\">����� ����������.</h2>";
print "<center><strong><a href=\"$cgiurl?cf=wall&walljob=gwf$mm\">[�������� �����]</a></strong></center>\n";
print "<br>";
print "<table border=0 width=100% cellpadding=0 cellspacing=0>\n";
@wwall=&readtxtfile($wallfile,2);
$dd=$bn*$one_show_wall;
$lastmsg=$#wwall;
if ($dd>$lastmsg) {$dd=0};
$firstmsg=$lastmsg-$dd;
$untilmsg=$firstmsg-$one_show_wall+1;

if ($untilmsg<0) {$untilmsg=0;};

if ($lastmsg>=0) {
for($i=$firstmsg;$i>=$untilmsg;$i--) {
   print "<tr><td width=20%></td>";
   print "<td width=5% bgcolor=$tableback><td>";
   print "<td width=50% bgcolor=$tableback><br>";
   ($chkdaten,$chktimen,$chkuserip,$chkname,$chkemail,$chkmessage,$markend)=split(/\|/,$wwall[$i]);
   print "$chkmessage<br>";
   print "<p align=right><a href=\"mailto:$chkemail\">$chkname</a><br>";
   print "����: $chkdaten<br>�����: $chktimen</p>";
   print "<hr width=90%>";
   print "<td width=5% bgcolor=$tableback><td>";
   print "</td><td width=20%></td>";
   print "</tr>";
}
}

print "</table><br>\n";
$dd=int($lastmsg / $one_show_wall);
print "<center><strong>\n";

if ($bn>0){$k=$bn-1;print "<a href=$cgiurl?cf=wall\&bn=$k>&lt;&lt;</a>&nbsp;\n";}
for($i=0;$i<=$dd;$i++){
    if ($bn!=$i) {print "<a href=$cgiurl?cf=wall\&bn=$i>"}
    $k=$i+1;
    print "$k";
    if ($bn!=$i) {print "</a>"}
    print "&nbsp;\n";
}
if ($bn<$dd){$k=$bn+1;print "<a href=$cgiurl?cf=wall\&bn=$k>&gt;&gt;</a>&nbsp;\n";}
print "</strong><br><br>\n";
$k=$lastmsg+1;
print "�����: $k</center><br>\n";
print "<center><strong><a href=\"$cgiurl?cf=wall&walljob=gwf$mm\">[�������� �����]</a></strong></center>\n";
print "<br>$walldocend\n";
print "</body></html>";
}

sub write_on_wall{
  open(WALL,">>$filehead$wallfile") || die $!;
  flock(WWALL,2) if ($osname eq "UNIX"); 
  print WALL "$daten\|$timen\|$userip\|$name\|$email\|$message\|end\|\n";
  flock(WWALL,8) if ($osname eq "UNIX"); 
  close(WALL);
}

sub pwall {
  &init_var;
  $username="";
  $username=&get_var('usr','\n|��');  # MultiUser
  if ($username eq "fmz") {
      &init_formoza;
  } elsif ($username eq "er") {
      &init_er;
  }

  if ($_[0] eq "gwf") {
     &get_wall_form;
     exit 0;
  }
  &write_on_wall if ($_[0] eq "sign");
  $bn=&get_var('bn','\n|��');  # BlockNumber
  if ($bn eq "") {$bn=0;}
  &return_wall;
}


##############################################
sub get_wall_form {

$k="";
$k="&usr=$username" if ($username ne "");

print <<HTML;
<html>
<head>
<title>$roomtitle - ����� ����������.</title>
<meta name=Author content=EastWood>
<link rel='stylesheet' TYPE='text/css' HREF='$cssurl'>
</head>

<body bgcolor=$wallbgcolor text=$walltextcolor $stdbgimg
 alink=$wallalink vlink=$wallvlink link=$walllink>
$adv
<h2 align=center>����� ����������</h2>

<table border=0 width=100% cellspacing=0 cellpadding=0>
  <tr>
    <td width=25%></td>
    <td width=50% bgcolor=$tableback><form action=$cgiurl?cf=wall$k
    method=POST>
      <input type=hidden name=walljob value=sign><p>&nbsp;</p>
      <table border=0 width=100% cellspacing=0 cellpadding=0>
        <tr>
          <td width=50%><div align=right><p><font face="MS Sans Serif" size=2><strong>����
          ���:&nbsp;&nbsp; </strong></font></td>
          <td width=50%><input type=text name=name size=15></td>
        </tr>
        <tr>
          <td width=50%><div align=right><p><strong><font face="MS Sans Serif" size=2>E-mail:
          &nbsp; </font></strong></td>
          <td width=50%><input type=text name=email size=15></td>
        </tr>
        <tr>
          <td width=100% colspan=2><div align=center><center><p><strong><font
          face="MS Sans Serif" size=2><br>
          ���� ���������:</font></strong></td>
        </tr>
      </table>
      <div align=center><center><p><textarea rows=5 name=message cols=25></textarea></p>
      </center></div><div align=center><center><p><input type=submit
      value=�������� name=WallSBTN></p>
      </center></div><div align=center><center><p>&nbsp;</p>
      </center></div>
    </form>
    </td>
    <td width=25% align=center></td>
  </tr>
</table>
<br>$walldocend
</body>
</html>
HTML
}

sub init_formoza{
      $roomtitle="FORMOZA -";
      $wallfile="fmzwall.txt";
      $stdbgimg="/images/fmzback.jpg";
      $wallbgcolor="#FFFFFF";
      $walltextcolor="#000000";
      $wallvlink="#0000FF";
      $wallalink="#00FFFF";   
      $walllink="#0000FF";
      $tableback="#FFFFFF";
}

sub init_er{
      $filehead=$erfiles;
      $roomtitle="ER ";
      $wallfile="wall.txt";
      $stdbgimg="/images/erbg.gif";
      $wallbgcolor="#000000";
      $walltextcolor="#00FF00";
      $wallvlink="#00FF00";
      $wallalink="#00FF00";   
      $walllink="#00FF00";
      $tableback="#393939";
}
