sub message_show {
local($chkusersex1)     ="<font size=-2>$chkusersex</font>" if (($allow_sex2==1) || (($allow_sex2==2) && (($mark eq "login") || ($mark eq "logout"))));
$temp3=&StrToHex($chkusername);
local($chkaddwordcolor1)="<font color=$chkaddwordcolor>" if ($chkaddwordcolor ne "");
local($chkaddwordcolor2)="</font>" if ($chkaddwordcolor ne "");

local($chkusername1)    ="<a href=\"javascript:parent.WTD('$temp3','$chkidt')\">$chkaddwordcolor1$chkusername$chkaddwordcolor2</a>";
local($chkusername1)    ="<u>$chkaddwordcolor1$chkusername$chkaddwordcolor2</u>" if ($chkusername eq $username);
if ($usersexcolor{$chkusersex}) {local($chkusername1)="<font color=$usersexcolor{$chkusersex}>$chkusersex1 $chkusername1</font>";}
else {local($chkusername1)="$chkusersex1$chkusername1";}
local($chktowho1)       =$chktowho;
local($chktowho1)       ="<u>$chktowho</u>" if ($chktowho eq $username); 
local($chktimen1)       ="<font size=-3>($chktimen)</font>" if ($allow_time==1);
local($chkuserip1)      ="<font size=-3>[$chkuserip]</font>" if ($userlevel>=$level_seeip);

if ($mark eq "says") {
   if ($chktowho eq "") {
      print "$chkaddwordcolor1$chkusername1$chkuserip1 : $chksays$chkaddwordcolor2$chktimen1<br>"; $messageshow++;
   }
   elsif (($chktowho ne "") && ($chktowhoway ne "private")) {
      print "$chkaddwordcolor1$chkusername1$chkuserip1 :$chksays$chkaddwordcolor2$chktimen1<br>"; $messageshow++;
   }
   elsif (($chktowho ne "") && ($chktowhoway eq "private") && (($IDT eq $chkidt2) || ($chkidt eq $IDT))) {
      print "<I>...$chkaddwordcolor1$chkusername1$chkuserip1 <small>[!! ������ !!]</small>: $chksays$chkaddwordcolor2$chktimen1</I><br>"; $messageshow++;
   }
   elsif (($chktowho ne "") && ($chktowhoway eq "private") && ($userlevel>=$level_seeprivate)) {
      print "$chkaddwordcolor1$chkusername1$chkuserip1 private!!! $cktowho1 : $chksays$chkaddwordcolor2$chktimen1<br>"; $messageshow++;
   }
}
elsif ($mark eq "login") {
   print "<font size=2 color=$loginword><strong>$roomtitle ��������: $chkusername1$chkuserip1 � ���� � ����.</strong> $chktimen1</font><br>"; $messageshow++;
} 
elsif ($mark eq "logout") {
   $temp="�������";
   $temp="��������" if ($chkusersex eq "�������");
   print "<font size=2 color=$logoutword><strong>$roomtitle ��������: $chkusername1$chkuserip1 $temp ���.</strong> $chktimen1</font><br>"; $messageshow++;
}  
elsif ($mark eq "server") {
   print "<font size=2 color=$loginword><strong>$chksays</strong> $chktimen1</font><br>"; $messageshow++;
}  

}
