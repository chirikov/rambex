sub check_ban {

@banlist=&readtxtfile($banlistfile,2);
@banlist=sort @banlist;

foreach (@banlist) {
   ($chkuserip,$chkcook,$kname,$chkdate,$chkreason,$who,$end) = split(/\|/,$_);
   if ($chkuserip ne "0.0.0.0"){
      if ($chkuserip eq $userip) {return "yes";}
   } else {
       if ($cookie ne ""){
            if ($cookie eq $chkcook){return "yes";}
       }
   }
}

return "no";
}
