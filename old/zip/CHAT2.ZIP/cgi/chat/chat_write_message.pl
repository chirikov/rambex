sub write_message {

$lock_file=$lock_file_message;
&check_lock(25); 
open(MESSAGE,">>$filehead$messagefile") || $err++;



if ($_[0] eq "says") {
   print MESSAGE "$daten\|$timen\|says\|$userip\|$username\|$userlevel\|$usersex\|$towhoway\|$towho\|$addwordcolor\|$addsays\|$addsign\|$says\|$IDT\|$IDT2\|end\|\n"; 
}
elsif ($_[0] eq "login") {
   print MESSAGE "$daten\|$timen\|login\|$userip\|$username\|$userlevel\|$usersex\|\|\|\|\|\|\|$IDT\|$IDT2\|end\|\n";
}
elsif ($_[0] eq "logout") {
   print MESSAGE "$daten\|$timen\|logout\|$userip\|$username\|$userlevel\|$usersex\|\|\|\|\|\|\|$IDT\|$IDT2\|end\|\n"; 
}
elsif ($_[0] eq "server") {
   print MESSAGE "$daten\|$timen\|server\|$userip\|$username\|$userlevel\|$usersex\|$towhoway\|$towho\|$addwordcolor\|$addsays\|$addsign\|$says\|$IDT\|$IDT2\|end\|\n"; 
}
close(MESSAGE);
&clean_up;
$lock_file=$lock_file_online;
}
