sub return_online {

$temp="online";
print "<html><head><title>online</title>";
print "<META HTTP-EQUIV=REFRESH CONTENT='$reloadonl;URL=$cgiurl?cf=$temp$userinfo'>";
print "<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=windows-1251\">";
print "</head>";
print "<body $stdbgimg bgcolor=$onlineback text=$onlineword vlink=#00FFFF link=#00FFFF alink=#00FFFF><center>";
print "$uponline";

print "<br><table border=0><tr><td align=left><font size=2>";

$temp="";

@online=&readtxtfile($onlinefile,"true");
$pcount;
print "<table border=0 width=100% cellpadding=0 cellspacing=0>";
foreach (@online) {
   ($mark,$chkuserip,$chkusername,$chkuserlevel,$chkusersex,$chkusericon,$chktimen,$chksecn,$chkkey,$chkidt,$chkcolor,$chkproxy,$chkcook,$chkproxyip,$markend,$last)=split(/\|/,$_);
   if (($mark eq "online") && ($markend eq "end")) {
      if ($temp ne "$chkuserip\|$chkusername\|$chkuserlevel") {
         print "<tr>";
         if ($allow_sex1==1) {
            print "<td width=20%>\n";
            print "<font color=$usersexcolor{$chkusersex}" if ($usersexcolor{$chkusersex});
            print " size=-2>Boy</font> " if ($chkusersex eq "�������");
            print " size=-2>Girl</font> " if ($chkusersex eq "�������");
            print "</font>" if ($usersexcolor{$chkusersex});  
            print "</td>\n";
         }
         $temp4=&StrToHex($chkusername);
         print "<td width=50%>&nbsp;&nbsp;";
         print "<a href=\"javascript:parent.Inf('$temp4','$chkidt')\">$chkusername</a>" if (($chkuserlevel>1) || ($userlevel>2));
         print "$chkusername" if (($chkuserlevel<=1) && ($userlevel<3));
         print "<font size=-1>  [$chkuserlevel]</font>" if ($userlevel>=$level_seelevel);
         if ($userlevel>2){
         if (($chkproxy eq "true") || ($chkcook eq "false")){
            print "<font size=-2 color=red>";
            print "{p}" if ($chkproxy eq "true");
            print "{nc}" if ($chkcook eq "false");
            print "</font>";
         }
	 }
         print "</td>";
         print "</tr>";
	 $pcount++;
      }
      $temp="$chkuserip\|$chkusername\|$chkuserlevel";
   }
}
print "</table>\n";

print "<br><br><font size=2><strong>�����: $pcount</strong></font>";
 
print "</font></td></tr></table>\n";
print "</body></html>\n";
}

