sub get_user_info2{
@online=&readtxtfile($onlinefile,"true");
$exist="no";
foreach (@online) {      
   ($mark,$chkuserip,$chkusername,$chkuserlevel,$chkusersex,$chkusericon,$chktimen,$chksecn,$chkkey,$chkidt,$chkcolor,$chkproxy,$chkcook,$chkproxyip,$markend,$last)=split(/\|/,$_);
   $temp1="$chkidt";
   if ($temp1 eq "$IDT2"){ 
          $exist="yes";
          $username2=$chkusername;
          $userip2=$chkuserip;
          $userlevel2=$chkuserlevel;
          $usersex2=$chkusersex;
          $timen2=$chktimen;
          $color2=$chkcolor;
	  $cookie2=$chkcook;
          $proxy2=$chkproxy;
          $proxyip2=$chkproxyip;
          return "yes";
   }
}
return "no";
}

sub get_user_info{
@online=&readtxtfile($onlinefile,"true");
$exist="no";
foreach (@online) {      
   ($mark,$chkuserip,$chkusername,$chkuserlevel,$chkusersex,$chkusericon,$chktimen,$chksecn,$chkkey,$chkidt,$chkcolor,$chkproxy,$chkcook,$chkproxyip,$markend,$last)=split(/\|/,$_);
   $temp1="$chkusername\|$chkkey\|$chkidt";
   if ($temp1 eq "$username\|$KEY\|$IDT"){ 
          $exist="yes";
          $username=$chkusername;
          $userlevel=$chkuserlevel;
          $usersex=$chkusersex;
          $timene=$chktimen;
	  $color=$chkcolor;
          return "yes";
   }
}
return "no";
}

sub write_online {
local($temp1)="";
local($temp2)= 0;
&check_lock(25);
@online=&readtxtfile($onlinefile,"false");
if (!open(ONLINE,">$filehead$onlinefile")) {$err++;}
$temp2=0;
$exist="no";
foreach (@online) {      
   ($mark,$chkuserip,$chkusername,$chkuserlevel,$chkusersex,$chkusericon,$chktimen,$chksecn,$chkkey,$chkidt,$chkcolor,$chkproxy,$chkcook,$chkproxyip,$markend,$last)=split(/\|/,$_);
   $temp1="$chkusername\|$chkkey\|$chkidt";
   if ($temp1 eq "$username\|$KEY\|$IDT"){ 
          $chkuserip=$userip;
	  $chkcook=$cookie;
          $chkproxy=$proxy;
          $chkproxyip=$proxyip;
          $exist="yes";
          if ($cf ne "login") {
              $chksecn=$secn;
              $username=$chkusername;
              $userlevel=$chkuserlevel;
              $usersex=$chkusersex;
#              $usericon=$chkusericon;
              $timene=$chktimen;
              $color=$chkcolor;
      	  }
	  if ($_[0] eq "outline") {
                $temp2=1;
	  }
   }

   if (!(($chksecn<$secn-$reloadxxx) || ($chksecn>$secn+$reloadxxx))) {
       if ($temp2==0){
          print ONLINE "online\|$chkuserip\|$chkusername\|$chkuserlevel\|$chkusersex\|$chkusericon\|$chktimen\|$chksecn\|$chkkey\|$chkidt\|$chkcolor\|$chkproxy\|$chkcook\|$chkproxyip\|end\|\n";
       }
       $temp2=0;
   }
}

if (($cf eq "login") && ($exist ne "yes")){
          print ONLINE "online\|$userip\|$username\|$userlevel\|$usersex\|$usericon\|$timen\|$secn\|$KEY\|$IDT\|$color\|$proxy\|$cookie\|$proxyip\|end\|\n";
}
$allow_html=1 if ($userlevel>=3);
close(ONLINE);
&clean_up;
return "TRUE";
}

sub AdminAdding{
$toidt=&get_var('toidt','\n|��');
$IDT2 = $toidt;
$temp=&get_user_info2;
print <<HTML;
<script language="JavaScript">
<!--
function SetFunction(a){
	document.forms[0].func.value=a;
}
//-->
</script>
HTML
print "<hr>";
if ($proxy2 eq "true") {
	print "<strong>r_IP:</strong>$userip2<br>";
	print "<strong>p_IP:</strong>$proxyip2<br>";
} else {print "<strong>IP</strong>:$userip2<br>";}
if ($cookie2 eq "false") {print "<font color=red size=-1>No cookies</font><br>";}
print "<form action=$cgiurl?cf=reaction$userinfo method=post>\n";
print "�������:<input type=text name=reason size=10><br>\n";
print "<input type=hidden name=toidt value=$toidt>\n";
print "<input type=hidden name=func value=clearwall>\n";
print "<font color=#00000><input type=submit value=�������� onClick=SetFunction(\"kick\")><br>\n";
print "<font color=#00000><input type=submit value=������� onClick=SetFunction(\"del\")><br>\n";
print "<input type=submit value=IP_Close onClick=SetFunction(\"close\")><br>\n" if ($userlevel>=4);
print "<input type=submit value=CLEAR onClick=SetFunction(\"clear\")><br>\n";
print "<input type=submit value=SRV_MSG onClick=SetFunction(\"servermsg\")><br>\n" if ($userlevel>=4);
print "</font>";
print "[<a href=$cgiurl?cf=gah target=_blank>Admin_Form</a>]<br>" if ($userlevel>=4);
print "[<a href=$cgiurl?cf=reaction$userinfo\&func=banlist target=_blank>Ban List</a>]<br>";
print "[<a href=$cgiurl?cf=alluser target=_blank>All Users</a>]<br>";
print "</form><hr>";
}

sub get_Info_html{
$toidt=&get_var('toidt','\n|��');
$temp9=&StrToHex($UNAME);
print <<FORM;
<html>
<head type="refresh">
<title>$roomtitle - ����������</title>
<meta name="Author" content="EastWood">
<link rel="stylesheet" TYPE="text/css" HREF="$cssurl">
</head>
<body $stdbgimg bgcolor=$funcback text=#FFFFDD vlink=#FFFF00 link=#FFFF00 alink=#FF0000>
<br>
<center>
$UNAME<br><br>
<a href="$cgiurl?cf=infoabout\&usern=$UNAME" target=_blank>���������� ����</a><br>
<a href="javascript:parent.WTD('$temp9','$toidt')">�������� �����</a>
<br>
FORM
if ($userlevel>2) {
&AdminAdding;
}
print <<FORM;
<br>
[<a href="$cgiurl?cf=online$userinfo">�����</a>]
</center>
</body>
</html>
FORM
}

sub delete_user{

@online="";
&check_lock(25);
@online=&readtxtfile($onlinefile,"false");
if (!open(ONLINE,">$filehead$onlinefile")) {$err++;}
foreach (@online) {      
   ($mark,$chkuserip,$chkusername,$chkuserlevel,$chkusersex,$chkusericon,$chktimen,$chksecn,$chkkey,$chkidt,$chkcolor,$chkproxy,$chkcook,$chkproxyip,$markend,$last)=split(/\|/,$_);
   $temp1="$chkidt";
   if ($temp1 ne "$IDT2"){ 
          $exist="yes";
          print ONLINE "online\|$chkuserip\|$chkusername\|$chkuserlevel\|$chkusersex\|$chkusericon\|$chktimen\|$chksecn\|$chkkey\|$chkidt\|$chkcolor\|$chkproxy\|$chkcook\|$chkproxyip\|end\|\n";
   }
}
close(ONLINE);
&clean_up;
return "true";
}
