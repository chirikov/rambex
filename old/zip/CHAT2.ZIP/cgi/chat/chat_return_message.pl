do "$cgipath$cgi_messageshow";
sub return_message {

$lock_file=$lock_file_message;
@message=&readtxtfile($messagefile,"true");

if ($#message>$allow_message*10) {
   &check_lock(25);
#   if ($allow_messagerecord==1) {;}
   open(MESSAGE,">$filehead$messagefile") || $err++;
   for($i=0;$i<=$#message;$i++) {
      if ($i<$#message-$allow_message*2) {if ($allow_messagerecord==1) {print MESSAGERECORD "$message[$i]";}}
      else {print MESSAGE "$message[$i]";}
   }
   close(MESSAGE);
   &clean_up;
}

$lock_file=$lock_file_online;

$messagerecordnumber=$#message;
splice(@message,0,$#message+1-$allow_message*2);
print "<html><head><title>���� ���������</title>\n";

$meta = "<META HTTP-EQUIV=REFRESH CONTENT='$reloadmsg;URL=$cgiurl?cf=look$userinfo'>";
$body = "<body bgcolor=$messageback text=$messageword vlink=#00FFFF link=#00FFFF alink=#00FFFF>";


print $meta;
print "<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=windows-1251\">";
print "</head>$body<basefont size=4>";

print "$uptitle";

$messageshow=0;
for($i=$#message;($i>=0) && ($messageshow<=$allow_message);$i--) {
   ($chkdaten,$chktimen,$mark,$chkuserip,$chkusername,$chkuserlevel,$chkusersex,$chktowhoway,$chktowho,$chkaddwordcolor,$chkaddsays,$chkaddsign,$chksays,$chkidt,$chkidt2,$markend,$last)=split(/\|/,$message[$i]);
   if ($markend eq "end") {&message_show;}
}
print "</body></html>\n";
}

