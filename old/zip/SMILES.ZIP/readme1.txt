These images were all found in the public domain and
have been modified to be used with BlueChat.

To use these images with BlueChat, first delete the original
smile1.gif, smile2.gif, and smile3.gif

Then select 3 new images and rename them to
smile1.gif, smile2.gif and smile3.gif

smile1.gif is the smiley face
smile2.gif is the frown
smile3.gif is the wink

Place them in your image directory and you're all set.

The images should now show up when :) or :( or ;) is sent in chat.
(assuming the $imagedir variable is set correctly in bc_chat.cgi)